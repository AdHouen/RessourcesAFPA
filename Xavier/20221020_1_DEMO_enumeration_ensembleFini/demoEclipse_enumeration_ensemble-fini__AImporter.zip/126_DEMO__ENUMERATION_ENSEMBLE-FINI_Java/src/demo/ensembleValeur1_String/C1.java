package demo.ensembleValeur1_String;

public class C1  {
	public static final String CouleurVERT = "VERT" ;//COULEUR_VERT
	public static final String CouleurORANGE = "ORANGE" ;
	public static final String CouleurROUGE = "ROUGE" ;
	
}
