package bookshop.domain;

public class Auteur extends Personne{
	
	@Override
	public String toString() {
		return "Auteur [ " + super.toString() + "]";
	}

	@Override
	public void parle() {
		System.out.println("c\'est long d\'écrire un livre");		
	}

	public static void main(String[] args) {
		Auteur a1 = new Auteur();
		System.out.println("un auteur :" +new Auteur());
		
		a1.parle();
	}

}
