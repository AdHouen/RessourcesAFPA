package demo.ensembleValeur3_Int_Interface;

public interface ICouleurFeu {

	
	// sous-entendu :public static final
	int CouleurVERT = 0 ;
	int CouleurORANGE = 1 ;
	int CouleurROUGE = 2 ;
	/*
	public static final int VERT = 0;
	public static final int ROUGE = 1;
	public static final int ORANGE =2;
	 */
	
	String[] tabFeuMulticolore = {"VERT", "ORANGE" , "ROUGE" };

	//exemple de la signature d'une méthode dans une interface
	//long factorielle(long n);
	//public abstract long factorielle(long n);
}
