package bookshop.domain;

public class Utilisateur extends Personne {

	private String idUtilisateur;

	
	public Utilisateur(String nom, String prenom, String idUtilisateur) {
		super(nom, prenom);
		this.idUtilisateur = idUtilisateur;
	}

	public Utilisateur() {
		this("inconnu", null, "ID inconnu");
	}


	public String getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(String idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}

	
	@Override
	public String toString() {
		return "Utilisateur [idUtilisateur=" + idUtilisateur + ", "+  super.toString() +"]";
	}

	@Override
	public void parle() {
		System.out.println("La cotisation est trop chère");		
	}
	
	
	public static void main(String[] args) {
		Utilisateur u1 = new Utilisateur("Osouf", "Olivier","23456");
		Utilisateur u2 = new Utilisateur("Dos Martires", "Victor","67329");

		Utilisateur jean = new Utilisateur();
		jean.setNom("Castex");
		jean.setPrenom("Jean");
		jean.setIdUtilisateur("wxcvb");
		
		System.out.println("u1 :" + u1.toString());
		System.out.println("u2 :" + u2);
		System.out.println("jeannot :" + jean);
		
		System.out.print("L\'utilisateur " + u1.getNom()+ "  "+ u1.getIdUtilisateur() + " dit :"); u1.parle();
		System.out.print("L\'utilisateur " + u2.getNom()+ "  "+ u2.getIdUtilisateur() + " dit :"); u2.parle();
		System.out.print("L\'utilisateur " + jean.getNom()+ "  "+ jean.getIdUtilisateur() + " dit :"); jean.parle();
		System.out.println();
		
	}
}
