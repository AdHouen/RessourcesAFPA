package fr.afpa.util;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Scanner;
import fr.afpa.math.Math;

public class Convertisseur {

	public static void main( String [] args) throws IOException{
		Scanner sc = new Scanner(System.in);
		BigDecimal bg = null;
		BigDecimal resultat = null;
		String entreeClavier = null;
		 
		System.out.print("\nEntrez la somme en euros : ");
	    entreeClavier = sc.nextLine();
	    
	    // NOK val = Double.parseDouble( entreeClavier );
	    bg = new BigDecimal( entreeClavier );

	    resultat = Math.euroToDollar( bg );
	    System.out.println( "montant equivalent en dollars: "
	    		+ resultat );
	    System.out.println();
	    System.out.println( "\nAppel du pendant dollarToEuro dans la foulée: "
	    		+ Math.dollarToEuro( resultat ));

	    System.out.print("Entrez la somme en dollars : ");
	    entreeClavier = sc.nextLine();
	    
	    //NOK double val = Double.parseDouble( entreeClavier );
	    bg = new BigDecimal( entreeClavier );
	    
	    resultat = Math.dollarToEuro( bg );
	    System.out.println( "montant equivalent en Euros: "
	    		+ resultat );
	    
	    System.out.println( "\nAppel de euroToDollar dans la foulée: "
	    		+ Math.euroToDollar(resultat));
	    sc.close();
	}
	//////////////////////////////////////////
	// AFICHAGE CONSOLE
	//Entrez la somme en euros : 100
	//montant equivalent en dollars: 118.82
	//
	//Appel de DollarToEuro dans la foulée: 100.00
	//Entrez la somme en dollars : 100
	//montant equivalent en Euros: 84.16
	//
	//Appel de euroToDollar dans la foulée: 100.00
}
