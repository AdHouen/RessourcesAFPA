package bookshop.domain;

public abstract class Personne implements IBavard{

	/** le nom de personne*/
	private String nom;
	
	private String prenom;

	public Personne(String nom, String prenom) {
		//super();		
		this.nom = nom;
		this.prenom = prenom;
	}
	

	public Personne() {
		this("Le Stagiaire" , " Masqué");
	}


	public String getNom() {
		return nom;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	
	@Override
	public String toString() {
		return "Personne [nom=" + nom + ", prenom=" + prenom + "]";
	}

//	@Override
//	public void parle() {
//		System.out.println("Blablabla");		
//	}

	//abstract
	@Override
	public abstract void parle();

	public static void main(String[] args) {

//		Personne toto = new Personne("Lariflette", "Toto");
//		Personne manu = new Personne("Macron", "Emmanuel");
//		
//		Personne jean = new Personne();
//		jean.setNom("Castex");
//		jean.setPrenom("Jean");
//		
//		System.out.println("toto :" + toto.toString());
//		System.out.println("manu :" + manu);
//		System.out.println("jeannot :" + jean);
//
//		System.out.print("La personne " + toto.getNom()+ " dit :"); toto.parle();
//		System.out.print("La personne " + manu.getNom()+ " dit :"); manu.parle();
//		System.out.print("La personne " + jean.getNom()+ " dit :"); jean.parle();

	}

}
