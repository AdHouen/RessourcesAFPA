package demo.ensembleValeur2_Int;

public class TestC1 {

	public static void main(String[] args) {
		

		//DECLARATION //AFFECTATION
		int feu = C1.CouleurROUGE;
		
		 //feu = feu + 3;//Pb :  contrôle de la valeur ?
		
		//AFFICHAGE : on s'appuie sur le tableau de chaîne
		System.out.println("valeur du feu :" + C1.TabFeuMulticolore[feu] );

		//UTILISATION :  == des primitifs
		if(feu == C1.CouleurVERT){
			System.out.println("On leve la barriere");
		}
		else if(feu == C1.CouleurORANGE){
			System.out.println("Sonnerie + On baisse la barriere");
		}
		else if(feu == C1.CouleurROUGE){
			System.out.println("On baisse la barriere");
		}
		else{
			throw new IllegalArgumentException("Cas impossible");
		}
		
		//UTILISATION:   le switch
		switch( feu){
		case C1.CouleurVERT:
			System.out.println("On leve la barriere");
			break;
		case C1.CouleurORANGE:
			System.out.println("Sonnerie + On baisse la barriere");
			break;
		case C1.CouleurROUGE:
			System.out.println("On baisse la barriere");
			break;
			
		default:
			throw new IllegalArgumentException("Cas impossible");

		}
		/* Le switch pour une variable enti�re ou char*/
		switch(feu)
		{
			case C1.CouleurROUGE:
				System.out.println("Arr�tez vous !");
	
				break;
			case C1.CouleurORANGE:
				System.out.println("Arr�tez vous !");
	
				break;	
			case C1.CouleurVERT:
				System.out.println("Vous pouvez avancer !");
	
				break;
			default:
				System.out.println("Cas non g�r�");
				throw new IllegalArgumentException("Cas non g�r�");
	
				//break;
		}
		
	}

}
