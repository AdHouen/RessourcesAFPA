package evenement.tests.e01_classesSeparees;
import java.awt.event.ActionEvent; //Evenement
//Interface correspondant au type d'�v�nement
import java.awt.event.ActionListener;
import javax.swing.*;//Les composants
import java.awt.GridLayout; //Le Layout
import evenement.outils.TirageLotoFactory;

//La classe �couteur est externe ("s�par�e") de la classe frame
//Elle correspond � l'objet �couteur (listener)
///////////////////////////////////////////////////////
class EcouteurNouveauTirage implements ActionListener
{	
	public void actionPerformed(ActionEvent ev) {
		JOptionPane.showMessageDialog (
				null, "Voici le dernier\n tirage du Loto:\n " + 
					TirageLotoFactory.newInstance().toString()
		);
	}
}
//penser � intancier puis abonner aupr�s du contr�le

public class TirageLoto {
	public static void main(String[] args) {
		//visibilit� "package access" obligatoire!
		//JLabel lblResultatLoto = new JLabel (); 
		
		JButton cmdNouveauTirage = new JButton ("Nouveau tirage");
		
		//pour les clics-bouton (ActionEvent))
		//intancier l'objet Listener   puis l'abonner aupr�s du contr�le
		cmdNouveauTirage.addActionListener( new EcouteurNouveauTirage() );
	
		JFrame fenetre = new JFrame ("Resultats de Loto");
		fenetre.getContentPane().setLayout(new GridLayout (2, 1));
		fenetre.getContentPane().add(cmdNouveauTirage);
		//fenetre.getContentPane().add(lblResultatLoto);
		fenetre.pack();
		fenetre.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		fenetre.setVisible(true);
	}
}
