package demo.ensembleValeur2_Int;




public class C1  {
//	public static String CouleurVERT = "VERT" ;
//	public static String CouleurORANGE = "ORANGE" ;
//	public static String CouleurROUGE = "ROUGE" ;
	
	public static final int CouleurVERT = 0 ;
	public static final int CouleurORANGE = 1 ;
	public static final int CouleurROUGE = 2 ;

	static String[] TabFeuMulticolore = {"VERT", "ORANGE" , "ROUGE" };
	
	/**
	 * Pour la valeur enti�re pass�e en param�tre, elle retourne une cha�ne qui correspond � la couleur 
	 * @param f l'entier repr�sentant la couleur
	 * @return  retourne une cha�ne qui correspond � la couleur 
	 */
	public static String couleurFeu(int f){
		//String retour;
		
		switch(f)
		{
		case CouleurROUGE:
			//retour = "ROUGE";
			return "ROUGE";
			//break;
		case CouleurORANGE:
			return "ORANGE";
			//break;
		case CouleurVERT:
			return "VERT";
			//break;
		default:
			throw new IllegalArgumentException("Cas non g�r�");
			//break;
		}

		//return retour;
	}

}
