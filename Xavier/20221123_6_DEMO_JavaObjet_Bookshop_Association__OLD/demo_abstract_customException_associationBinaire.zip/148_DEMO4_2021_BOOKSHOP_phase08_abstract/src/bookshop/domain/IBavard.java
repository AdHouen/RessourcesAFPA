package bookshop.domain;

public interface IBavard {
	void parle();//public abstract
}
