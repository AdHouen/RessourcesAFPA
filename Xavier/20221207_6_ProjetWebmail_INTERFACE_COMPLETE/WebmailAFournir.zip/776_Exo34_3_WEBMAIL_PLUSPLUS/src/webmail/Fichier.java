/*
 * Cr�� le 17 oct. 2003
 */
package webmail;


import java.io.*;
import java.text.*;
import java.util.*;

import javax.swing.*;

/**
 * Gestion de fichier
 *
 *@author jrl
 *@version 1.0
 */
public class Fichier {
	

	private String m_nom;

	/**
	 * D�finit le nom du fichier
	 * @param file Nom du fichier
	 * @see Vector
	 */
	public Fichier(File file) {
		
		m_nom = file.getAbsolutePath();
	}

	/**
	 * D�finit le nom du fichier
	 * @param nom Nom du fichier
	 */
	public Fichier(String nom) 
	{
		m_nom = nom;
	}
	
	/**
	 * D�finit le chemin relatif du fichier sous la forme ./Msg/M20031024-0945.msg
	 * Chaque fichier � un nom unique 
     * Le r�pertoire ./Msg doit exister
	 */
	public Fichier() 
	{
		GregorianCalendar now = new GregorianCalendar ();
		SimpleDateFormat format = new SimpleDateFormat ("'./Msg/M'yyyyMMdd-HHmmss'.msg'");
		m_nom = format.format(now.getTime());
	}
	
	/**
	 * Retourne le contenu du fichier texte sous forme d'un Vector, un �l�ment par ligne
	 * @return le Vector
	 * @see Vector
	 */
	public Vector getLignes()
	{
		Vector local = new Vector();
		try {
			BufferedReader f = new BufferedReader(new FileReader(m_nom));
			for(;;) {
				String lg = f.readLine();
				if (lg==null) break;
				if (lg.length()>0) local.addElement(lg);
			}
			f.close();
		}
		catch (IOException e){
		}
		finally {	
			Collections.sort(local)	;	
		}
		return local;
	}
	
	/**
	 * Cr�er un fichier texte contenant la chaine
	 * @param val Contenu du fichier
	 */
	public void setContenu(String val)
	{
		try {
			PrintWriter f = new PrintWriter(new FileWriter(m_nom, true));
			f.println(val);
			f.close();
		}
		catch (IOException e){
			JOptionPane.showMessageDialog(null, "Sauvegarde du message impossible", "Erreur sur " + m_nom, JOptionPane.OK_OPTION);
		}
		finally {			
		}
	}
	
	/**
	 * Retourne le contenu d'un fichier texte sous forme d'une cha�ne unique
	 * @return Le contenu
	 */
	public String getContenu()
	{
		StringBuffer local = new StringBuffer();
		try {
			BufferedReader f = new BufferedReader(new FileReader(m_nom));
			for(;;) {
				String lg = f.readLine();
				if (lg==null) break;
				local.append(lg + "\n");
			}
			f.close();
		}
		catch (IOException e){
		}
		return local.toString();
	}

}
