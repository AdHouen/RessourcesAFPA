package evenement.tests.e05_classeImpliciteAnonyme_Lambda;
import javax.swing.*;import java.awt.*;
import java.awt.event.*;
import evenement.outils.TirageLotoFactory;
//
//CHOIX DE WindowBuilder
//Pour les listener: utilisation de classe anonyme Java (inner class)
/////////////////////////////////////////////////////////////////////
@SuppressWarnings("serial")
public class TirageLoto extends JFrame {

private JLabel lblResultatLoto;
private JButton cmdNouveauTirage;

private JButton cmdBouton2;
private JButton cmdBouton3;

public TirageLoto() {
	super("Resultats de Loto");
	// this.setSize(420, 320);
	// this.setResizable(false);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	initControles();
	this.pack();
	this.setVisible(true);
}
public void initControles() {
	lblResultatLoto = new JLabel("                        ");
	cmdNouveauTirage = new JButton("Nouveau tirage");
	
	//En faite, c'est surtout l'objet-�couteur (� abonner au composant)
	//et son handler qui nous int�resse !!  (pas d�finir une classe, son nom, ...)
	// -----> possibilit� de classe interne anonyme en Java

	cmdNouveauTirage.addActionListener(
			
			//instancier l'objet Listener   puis l'abonner aupr�s du contr�le
			//classe anonyme ( classe interne implicite (anonyme))
			new ActionListener() {
				public void actionPerformed(ActionEvent ev) {
					lblResultatLoto.setText(TirageLotoFactory.newInstance().toString());
					//Object source = ev.getSource();
			}
			
	});
	// Alternative en Java 8 et sa programmation fonctionnelle
	// ActionListener est une interface avec une seule m�thode (functional ?)
	// on peut utiliser une Lambda expression
	//cmdNouveauTirage.addActionListener( ev -> {lblResultatLoto.setText(TirageLotoFactory.newInstance().toString()); });
	cmdNouveauTirage.addActionListener( ev -> {lblResultatLoto.setText("Hello"); });

	cmdBouton2 = new JButton("2222");
	cmdBouton2.addActionListener( ev -> System.out.println("traitement bouton 2 :" + ev.getSource().getClass().getCanonicalName() ) );
	//intancier l'objet Listener   puis l'abonner aupr�s du contr�le
/*	cmdBouton2.addActionListener( new ActionListener() {
		public void actionPerformed(ActionEvent ev) {
			System.out.println("traitement bouton 2 ");
		}
	});*/
	
	cmdBouton3 = new JButton("3333");
	cmdBouton3.addActionListener( ev -> System.out.println("traitement bouton 3 ") );
	//intancier l'objet Listener   puis l'abonner aupr�s du contr�le
/*	cmdBouton3.addActionListener( new ActionListener() {
		public void actionPerformed(ActionEvent ev) {
			System.out.println("traitement bouton 3 ");
		}
	});*/

	this.getContentPane().setLayout( new GridLayout(2, 1) );
	this.getContentPane().add(cmdNouveauTirage);
	this.getContentPane().add(lblResultatLoto);
	
	this.getContentPane().add(cmdBouton2);
	this.getContentPane().add(cmdBouton3);
}
public static void main(String[] args) {
	new TirageLoto();
}
}
