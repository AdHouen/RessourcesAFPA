package demo.ensembleValeur3_Int_Interface;



public class C1  implements ICouleurFeu{
	
	
	public static void m1() {
		//System.out.println("valeur du feu :" + feu);

	}

	public static void m2() {

	}

	public static void main(String[] args) {
		
		int feu = CouleurVERT;
		feu = 6;//Pb :  contrôle de la valeur ?

		System.out.println("valeur du feu :" + tabFeuMulticolore[feu] );
		
		switch( feu){
		case CouleurVERT:
			System.out.println("On leve la barriere");
			break;
		case CouleurORANGE:
			System.out.println("Sonnerie + On baisse la barriere");
			break;
		case CouleurROUGE:
			System.out.println("Sonnerie + la barriere est baiss�e");
			break;
			
		default:
			throw new IllegalArgumentException("Cas impossible");

		}
		
/*
 * 		if(feu.equals(CouleurVERT)){
			System.out.println("On leve la barriere");
			
		}
		else if(CouleurORANGE.equals(feu)){
			System.out.println("Sonnerie + On baisse la barriere");

		}
		else if(feu.equals(CouleurROUGE)){
			System.out.println("Sonnerie + On baisse la barriere");

		}
		else{
			throw new IllegalArgumentException("Cas impossible");

		}*/
		/* Le switch pour une variable enti�re ou char*/
		switch(feu)
		{
			case CouleurROUGE:
				System.out.println("Arr�tez vous !");
	
				break;
			case CouleurORANGE:
				System.out.println("Arr�tez vous !");
	
				break;	
			case CouleurVERT:
				System.out.println("Vous pouvez avancer !");
	
				break;
			default:
				System.out.println("Cas non g�r�");
				throw new IllegalArgumentException("Cas non g�r�");
	
				//break;
		}
	}

}
