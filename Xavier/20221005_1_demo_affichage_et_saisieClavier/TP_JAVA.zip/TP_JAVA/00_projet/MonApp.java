import java.util.Date;

public class MonApp
{
	 public static void main( String [] args )
	 {
		 
		 String message = "Hello World";
		System.out.println(message);//kjhkjkj
		/*
		kjlklklk
		jlkjkllk*/
	
		System.out.println(message +   "  les CDA" +   ",  il est :" + (new Date()).toString());

	
	
	
	 }
}
