///<summary>
/// Gestion de l'interface SCORM pour les pages Web devant �tre utilis�es dans un LMS.
/// Ce fichier doit �tre import� dans la page Web qui doit �tre scorm�e par la directive :
/// <script language="javascript" src="scripts/scorm.js"></script>
/// Cette directive sous-entend que le pr�sent fichier se trouve dans un sous-r�pertoire scripts
/// plac� au m�me niveau que la page web � scormer.
/// <author>Anadr�-Pierre LIMOUZIN</author>
/// <version>1.0</version>
/// <date>21 mars 2005</date>
///</summary>


///<summary>
/// Recherche r�cursive du frameset porteur de l'API SCORM
/// La recherche de fait � partir de la fen�tre courante contenant la page Web � scormer
/// en remontant vers la page conteneur jusqu'� la fen�tre top.
/// La norme IEEE impose que le niveau d'imbrication des fen�tres Web ne dd�passe pas 500.
///</summary>
///<param name="win">
/// Instance de la fen�tre � scormer.
/// Normalement ce doit �tre le fen�tre courante contenant la page web � scormer symbolis�e 
/// en javascript par le mot cl� "window".
///</param>
///<return>Instance de l'API SCORM trouv�e</return>
function findAPI(win)
{
	var findAPITries = 0;
	while ((win.API == null) && (win.parent != null) && (win.parent != win))
	{
		findAPITries++;
		if (findAPITries > 500)
		{
			window.alert("Pas d'API SCORM trouv�e -- le niveau d'imbrication des fen�tres est trop important.");
			return null;
		}
		win = win.parent;
	}
	return win.API;
}

///<summary>
/// Initialisation de la variable globale API, avec l'API SCORM port� par le LMS parent.
/// La recherche se fait d'abord dans la lign�e directe (window), 
/// puis dans dans la lign�e g�nerale (window.opener)
/// pour tenir compte des LMS qui ouvrent les pages Web dans une nouvelle instance de navigateur Web.
/// A la fin de cette methode, la variable globale API contient l'instance de l'API SCORM du LMS.
/// Si aucune API SCORM n'est trouv�e, API vaut null.
///</summary>
///<return>Aucun</return>
var API = null; 
initAPI(); //SCORM API 
function initAPI()
{
	API = findAPI(window);
	if ((API == null) && (window.opener != null) && (typeof(window.opener) != "undefined"))
	{
		API = findAPI(window.opener);
	}
	if (API == null)
	{
		// window.alert("API SCORM non trouv�");
		return;
	}
	// window.alert("API SCORM trouv� : API=" + API);

}

///<summary>
/// Cette fonction calcule la dur�e pendant laquelle la page Web scorm�e est jou�e.
/// Au moment du chargement de la page la variable debutPlay est initialis�e � l'instant Date.
/// Le temps est calcul� en diff�rentiel entre l'appel de la fonction et le chargement initial de la page.
///</summary>
///<return>Temps format� en cha�ne de caract�re au format hh:mn:ss.d</return>
var debut = new Date().getTime();

function calcule_duree()
{
	var fin = new Date().getTime();
	var temps = (fin - debut) / 1000;
	var ss = temps % 60;
	temps -= ss;
	var mn = temps % 3600;
	temps -= mn;
	mn /= 60;
	var hh = temps / 3600;
	return formatNN(hh) + ":" + formatNN(mn) + ":" + formatNN(ss);
}

///<summary>
/// Cette fonction converti un nombre en cha�ne de caract�re.
/// Un 0 est ajout� au d�but pour les nombres inf�rieurs � 10.
///</summary>
///<param name="">nombre entier � convertir</param>
///<return>Cha�ne de caract�re format�e NN</return>
function formatNN(n)
{
	return (n < 10) ? "0" + n : n;
}


///<summary>
/// Cette m�thode permet d'intialiser le LMS.
/// Elle doit �tre appell�e au chargement de la page,
/// en g�n�ral lors du traitement de l'�venement onload.
/// Cette fonction met � jour une vaiable globale 
/// pour que l'initialisation ne soit faite qu'une seule fois.
///</summary>
///<return>vrai si le LMS est initialis�</return>
var isInitialized = false;
function LMSInitialize()
{
	if (API == null) return false;
	if(!isInitialized)
	{
		var result = API.LMSInitialize("");
		if (result.toString() != "true")
		{
			return false
		}
		isInitialized = true;
	}
	return true;
}

///<summary>
/// Cette fonction cloture une session SCORM du LMS.
/// Cette fonction est appel�e au traitement du message onunload.
///</summary>
///<return>Code erreur du LMS</return>
function LMSFinish()
{
	if(isInitialized)
	{
		API.LMSFinish("");
	}
	return LMSGetLastError();
}

///<summary>
/// Met � jour une donn�e du LMS.
/// Les donn�es sont rang�es dans un tableau associatif du type key/value.
/// key et value sont des cha�nes de caract�res.
///</summary>
///<param name="strKey">Mot clef du LMS</param>
///<param name="strValue">Valeur associ�e au mot clef du LMS</param>
///<return>Code erreur du LMS</return>


function LMSSetValue(strKey, strValue)
{
	for (var i = 0; i < 32000; i++)
	{
		//Tempo sur le setvalue
		var tempo = 1;	
	}
	if(isInitialized)
	{
		API.LMSSetValue(strKey, strValue);
		if(LMSGetLastError() == 0){
			API.LMSCommit("");
		}
	}
	return LMSGetLastError();
}


///<summary>
/// Met � jour le status de la ressource dans le SMS.
///</summary>
///<param name="strStatus">Status de la ressource</param>
///<return>Code erreur du LMS</return>
function LMSSetStatus(strStatus)
{
	return LMSSetValue("cmi.core.lesson_status", strStatus);
}

///<summary>
/// Met � jour le score de la ressource dans le SMS.
///</summary>
///<param name="strStatus">Status de la ressource</param>
///<return>Code erreur du LMS</return>
function LMSSetScore(strScore)
{
	return LMSSetValue("cmi.core.score.raw", strScore);
}

///<summary>
/// Met � jour la dur�e pendant laquelle la ressource est jou�e dans le SMS.
///</summary>
///<return>Code erreur du LMS</return>
function LMSSetTime()
{
	var strTime = calcule_duree();
	return LMSSetValue("cmi.core.session_time", strTime);
}

///<summary>
/// Retrouve une donn�e du LMS.
/// Les donn�es sont rang�es dans un tableau associatif du type key/value.
/// key et value sont des cha�nes de caract�res.
///</summary>
///<param name="strKey">Mot clef du LMS</param>
///<return>Valeur associ�e au mot clef du LMS</return>
function LMSGetValue(strKey)
{
	if(!isInitialized) return "";
	return API.LMSGetValue(strKey);
}

///<summary>
/// Renvoie le dernier code erreur du LMS provoqu� par l'une des commande de l'API.
/// Si aucun API n'est trouv�, on consid�re qu'il n'y a pas d'erreur et 0 est renvoy�.
///</summary>
///<return>Code erreur du LMS</return>
function LMSGetLastError()
{
	if (API == null) return 0;
	return API.LMSGetLastError();
}

///<summary>
///</summary>
///<param name=""></param>
///<return></return>
