package evenement.outils;
import java.util.*;
public class TirageLotoFactory
{
  /**
   * Renvoie une liste de 6 nombres tires al�atoirement dans
   * un ensemble de nombres compris entre 1 et 49.
   */
public static List<Integer> newInstance ()
{
    // Creation d'une collection des 49 entiers de 1 a 49
	ArrayList<Integer> boulesLoto = new ArrayList<Integer> (49);
	for (int i = 1; i <= 49; i++)
	  boulesLoto.add (i);
	
	// Melange al�atoire de la collection boulesLoto
	Collections.shuffle (boulesLoto);
	// transtypage ascendant implicite d'une classe vers l'interface qu'elle impl�mente
	// Rappel: la classe java.util.ArrayList impl�mente java.util.List
	
	// Extraction des 6 premiers entiers de la collection m�lang�e
	return boulesLoto.subList(0, 6);
	// subList renvoie une collection de type List
}}

