package demo.ensembleValeur3_Int_Interface;

public class C2 extends C1{
	static int feu = CouleurVERT;

	
	public static void m1() {
		System.out.println("valeur du feu :" + tabFeuMulticolore[CouleurVERT]);

	}

	public static void m2() {

	}

	public static void main(String[] args) {
		//System.out.println("valeur du feu :" + C1.feu);
		m1();
	}

}
