package fr.afpa.math;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MathTest {
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}
	@BeforeEach
	void setUp() throws Exception {
	}
	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testFactorielleNeutre() {
		assertTrue(true, "Mettez le message qui explique le test (ici true)");//JUnit4
		assertTrue("Mettez le message qui explique le test (ici true)" , true);//JUnit5
		//fail("Not yet implemented");
	}

	@Test
	void testFactorielleTrois() {
		assertEquals(Math.factorielle(3), 6, "La factorielle de 3 vaut 6");
	}
	
//	public static void factorielleTestZero() {
//		//assertion : La factorielle de zero vaut 1
//		if( factorielle__recursive(0) == 1 )
//			System.out.println(" :Test OK");
//		else
//			System.err.println(" :Test NOK : La factorielle de zero vaut 1");
//	}	@Test
	void testFactorielleZero() {
		assertTrue("La factorielle de zero vaut 1", Math.factorielle(0) == 1);
	}
	
//	public static void factorielleTestMoinsSept() {
//		if( factorielle__recursive(-7) == -1 )
//			System.out.println(" :Test OK ");
//		else
//			System.err.println(" :Test NOK : La factorielle de -7 retourne -1");
//	}
	@Test void testFactoriellefactorielleTestMoinsSept() {
	    assertThrows(IllegalArgumentException.class,
	            ()->{Math.factorielle(-7);},
	            "La factorielle de -7 n'exite pas" );
	}
}
