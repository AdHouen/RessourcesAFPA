package biblio.metier_EcritureClasseMetierEntite;

public class BookshopException extends Exception {

	private static final long serialVersionUID = 1L;

	public BookshopException(String message) {
		super(message);
	}
	public BookshopException() {
		super("Pb généric sur l'application bookshop");
	}


	public static void main(String[] args) {
System.out.println(new BookshopException("Nombre maximum d'emprunts atteint"));
System.out.println(new BookshopException());
	}

}
