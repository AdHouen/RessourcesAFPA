package biblio.test;

public class C3{
	
	public static int soustraction( int val1 , int val2 )
	{
		
		return val1 - val2;
	}
}