package bookshop.domain;

public class Auteur extends Personne {

	public Auteur(String nom, String prenom) {
		super(nom, prenom);
	}

	public Auteur() {
		this("nom_inconnu", "prenom_inconnu");
	}

	@Override
	public String toString() {
		return "Auteur [" + super.toString() + "]";
	}
@Override 
public void parle() {
	//super.parle();
	System.out.println("Achetez mon livre");
	
}
	public static void main(String[] args) {
		Auteur a1 = new Auteur();
		a1.setNom("Poutine");
		a1.setPrenom("Vladimir");

		System.out.println("un auteur :" + a1);

		Auteur a2 = new Auteur("Remi","Ergé" );
		System.out.println("un auteur :" + a2);

	
		//transtypage ascendant//up-casting
		Personne p = a1;
		System.out.println();
		System.out.print("Vladimir " + p.getNom() + " dit :");p.parle();
		//Pour parle(), la MV va chercher la méthode la plus adaptée à l'objet !!!
		//Constat: Les méthodes sont virtuelles au runtime// ligature dynamique// dynamic binding
		System.out.println("la classe de l'objet p :" + p.getClass().getName());
		// la MV sait toujours d'où l'objet a été instancié


		//transtypage descendant (possible)
		Auteur a7 = (Auteur) p;
		System.out.print("un auteur a7 nom :" + a7.getNom()+ "  prenom:"+ a7.getPrenom() + " dit :"); a7.parle();

		//transtypage descendant IMPOSSIBLE//downcasting //java.lang.ClassCastException:
		//Utilisateur u34 = (Utilisateur) p;
		//System.out.print("L\'utilisateur " + u1.getNom()+ "  "+ u1.getIdUtilisateur() + " dit :");u1.parle();
	}
}
