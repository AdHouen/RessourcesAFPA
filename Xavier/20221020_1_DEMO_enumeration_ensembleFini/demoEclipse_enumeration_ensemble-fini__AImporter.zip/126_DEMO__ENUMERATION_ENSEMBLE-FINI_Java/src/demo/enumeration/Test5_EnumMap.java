
package demo.enumeration;
import java.util.EnumMap;
import java.util.Set;

public class Test5_EnumMap {

public static void main(String[] args) {
////////////////////////////////////////////////
//
//  une �num�ration comme clef d'un Dictionnaire
//
////////////////////////////////////////////////
	
EnumMap<EnumFeuMulticolore, String> libelles = new EnumMap<>(EnumFeuMulticolore.class);

libelles.put(EnumFeuMulticolore.ROUGE, "On baisse la barri�re");
libelles.put(EnumFeuMulticolore.VERT, "On l�ve la barri�re du passage � niveau");
libelles.put(EnumFeuMulticolore.ORANGE, "Sonnerie + n'avancez plus!");

System.out.println( libelles.get( EnumFeuMulticolore.ORANGE ) );
System.out.println();
Set<EnumFeuMulticolore> keys = libelles.keySet();
for (EnumFeuMulticolore enumFeuMulticolore : keys) {
	System.out.println( "les clefs:" + enumFeuMulticolore );
}
System.out.println();

Set<EnumFeuMulticolore> cles = libelles.keySet();
for (EnumFeuMulticolore e : cles){
	System.out.println( "voir l'ordre par d�faut -- " + libelles.get(e));

}
}}
//////////////////////////////////////////////////
//////AFFICHAGE SUR LA CONSOLE
//////////////////////////////////////////////////
//Sonnerie + n'avancez plus!
//la chaine :VERT
//la chaine :ORANGE
//la chaine :ROUGE
//voir l'ordre par d�faut -- On l�ve la barri�re du passage � niveau
//voir l'ordre par d�faut -- Sonnerie + n'avancez plus!
//voir l'ordre par d�faut -- On baisse la barri�re


//////////////////////////////////////////////////////////
//Faire ce code en d�mo pour voir les facilit�s d'Eclipse
//Set<EnumFeuMulticolore> cles = libelles.keySet();
//for (EnumFeuMulticolore e : cles){
//	System.out.println( "voir l'ordre par d�faut -- " + libelles.get(e));
//}

