package demo.ensembleValeur1_String;

public class TestC1 {

public static void main(String[] args) {
	
	//DECLARATION //AFFECTATION
	String feu = C1.CouleurVERT;
	//feu = "Salut";//Pb :  contrôle de la valeur ?

	//AFFICHAGE DE LA VALEUR
	System.out.println("valeur du feu :" + feu );


	//UTILISATION :  equals pour la comparaison d'objets ...
	if(feu.equals(C1.CouleurVERT)){
		System.out.println("On leve la barriere");
		
	}
	else if(C1.CouleurORANGE.equals(feu)){
		System.out.println("Sonnerie + On baisse la barriere");

	}
	else if(feu.equals(C1.CouleurROUGE)){
		System.out.println("Sonnerie +  barri�re baiss�e");

	}
	else{
		throw new IllegalArgumentException("Cas impossible");
	}
	
/*		NE MARCHE PAS jusqu'à JAVA6 compris*/
	switch( feu){
		case C1.CouleurVERT:
			System.out.println("On leve la barriere");
			break;
		case C1.CouleurORANGE:
			System.out.println("Sonnerie + On baisse la barriere");
			break;
		case C1.CouleurROUGE:
			System.out.println("Sonnerie +  barri�re baiss�e");
			break;
			
		default:
			throw new IllegalArgumentException("Cas impossible");
	}

	/* Le switch pour une variable enti�re ou char*/
	switch(feu)
	{
		case C1.CouleurROUGE:
			System.out.println("Arr�tez vous !");

			break;
		case C1.CouleurORANGE:
			System.out.println("Arr�tez vous !");

			break;	
		case C1.CouleurVERT:
			System.out.println("Vous pouvez avancer !");

			break;
		default:
			System.out.println("Cas non g�r�");
			throw new IllegalArgumentException("Cas non g�r�");

			//break;
	}
}

}
