/*
 * Cr�� le 2 avr. 2004
 */
package webmail;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 *
 *@author jrl
 *@version 1.0
 */
public class Parametre extends JDialog implements ActionListener{
	
	// D�finition des constantes informant sur le type de fermeture	
	public static final int OK = 0;
	public static final int ANNULER = -1;
	
	// Les controles de la boite (OK ANNULER + les autres)
	private JTextArea txtInfo = new JTextArea();
	private JButton cmdOK = new JButton("OK");
	private JButton cmdAnnuler = new JButton("Annuler");
	
	// Type de fermeture (ANNULER si ferm� par la X)
	private int typeFermeture = ANNULER;
	
	// Le constructeur m�morise le parent, le mode d'ouverture (modal) 
	// La fenetre se CACHE si on ferme par la x
	public Parametre (JFrame parent)
	{
		super(parent, "Choix des param�tres", true);
		this.setSize(300,200);
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		initControles();
	}
	
	// Pseudo-surcharge de la m�thode show() pour avoir une 
	// valeur de retour
	// On en profite pour passer les information d'entr�e
	public int showDialog(String info)
	{
		// Contr�les initialis�s en foction des entr�es
		txtInfo.setText(info);
		// M�thode bloquante jusqu'au HIDE
		this.setVisible(true); 
		return typeFermeture;
	}

	// Autant de getters() que d'informations � r�cup�rer
	public String getInfo()
	{
		return txtInfo.getText();
	}

	private void initControles() 
	{
		JPanel zoneClient = (JPanel) this.getContentPane();
		
		JPanel panBas = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JPanel panBouton = new JPanel (new GridLayout(0,2,10,10));
		panBas.add(panBouton);
		
		cmdOK.addActionListener(this);
		panBouton.add(cmdOK);		
		cmdAnnuler.addActionListener(this);
		panBouton.add(cmdAnnuler);
		
		zoneClient.add(new JScrollPane(txtInfo), BorderLayout.CENTER);
		zoneClient.add(panBas,  BorderLayout.SOUTH);		
	}

	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource() == cmdOK) cmdOK_click ();
		if (e.getSource() == cmdAnnuler) cmdAnnuler_click ();
	}

	// OK et ANNULER cachent la fenetre (sans la d�charger)
	private void cmdAnnuler_click() 
	{
		typeFermeture = ANNULER;
		this.hide();
	}

	private void cmdOK_click() 
	{
		typeFermeture = OK;
		this.hide();
	}

}
