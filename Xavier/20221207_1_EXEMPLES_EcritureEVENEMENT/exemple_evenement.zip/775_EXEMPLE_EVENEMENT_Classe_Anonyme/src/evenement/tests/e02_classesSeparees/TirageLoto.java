package evenement.tests.e02_classesSeparees;
import evenement.outils.TirageLotoFactory;
import javax.swing.*;import java.awt.*;import java.awt.event.*;

//La classe �couteur est externe ("s�par�e") de la classe frame
//Ici, on passe en param�tre la r�f�rence du composant � modifier
/////////////////////////////////////////////////////////////////
class EcouteurNouveauTirage implements ActionListener
{
	private JLabel lblResultatLoto2; //R�f�rence du composant � modifier
	
	//Constructeur ou on est oblig� de passer la r�f�rence du composant � modifier
	public EcouteurNouveauTirage( JLabel lblResultatLoto ) {
		
		this.lblResultatLoto2 = lblResultatLoto;
	}
	public void actionPerformed(ActionEvent ev) {
		// Mise a jour du label avec les num�ros d'un nouveau tirage
		lblResultatLoto2.setText( TirageLotoFactory.newInstance().toString() );
	}
}
//penser � intancier puis abonner aupr�s du contr�le

@SuppressWarnings("serial")
public class TirageLoto extends JFrame
{
	//visibilit� "package access" obligatoire!
	JLabel lblResultatLoto;
	private JButton cmdNouveauTirage;
	
	public TirageLoto() {
		super("Resultats de Loto");
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new GridLayout (2, 1));
		
		initControls();
		this.pack();
		this.setVisible(true);
	}
	private void initControls(){
		lblResultatLoto = new JLabel ();//affichage du tirage loto
	
		cmdNouveauTirage = new JButton ("Nouveau tirage");
		//intancier l'objet Listener puis l'abonner aupr�s du contr�le
		cmdNouveauTirage.addActionListener( new EcouteurNouveauTirage( lblResultatLoto ) );
	
		this.getContentPane().add(cmdNouveauTirage);
		this.getContentPane().add(lblResultatLoto);
	}
	public static void main(String[] args)
	{
		new TirageLoto();
	}
}
