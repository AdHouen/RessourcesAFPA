package bookshop.domain;

public class Utilisateur extends Personne {
	
	private String idUtilisateur;
	private Livre emprunt;//association

	
	public Utilisateur(String nom, String prenom, String idUtilisateur, Livre emprunt) {
		super(nom, prenom);
		this.idUtilisateur = idUtilisateur;
		this.emprunt = emprunt;
	}
	public Utilisateur() {
		this("nom_inconnu", "prenom_inconnu", "ID inconnu",null);
	}
	
	public String getIdUtilisateur() {
		return idUtilisateur;
	}
	public Livre getEmprunt() {
		return emprunt;
	}
	public void setIdUtilisateur(String idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}
	public void setEmprunt(Livre emprunt) {
		this.emprunt = emprunt;
	}

	@Override
	public String toString() {
		return "Utilisateur [idUtilisateur=" + idUtilisateur + ", emprunt=" + emprunt + ",  ["
				+ super.toString() + "]]";
	}
	
	@Override
	public void parle() {
		//super.parle();//pas utile
		System.out.println("La cotisation est trop chère");		
	}
	

	public static void main(String[] args) {
		Utilisateur u1 = new Utilisateur("MARIE JOSEPH", "Carthy", "34890",null);
		System.out.println("toString() de utilisateur u1 :" + u1);

		System.out.print("L\'utilisateur " + u1.getNom()+ "  "+ u1.getIdUtilisateur() + " dit :");u1.parle();
		
		//transtypage ascendant//up-casting
		Personne p = u1; 
		System.out.println("p :" + p.toString());
		System.out.println();
		//System.out.print("MARIE JOSEPH " + p.getNom()+ "  "+ p.getIdUtilisateur() + " dit :");p.parle();
		System.out.print("MARIE JOSEPH " + p.getNom() + " dit :");p.parle();
		//Pour parle(), la MV va chercher la méthode la plus adaptée à l'objet !!!
		//Constat: Les méthodes sont virtuelles au runtime// ligature dynamique// dynamic binding
		System.out.println("la classe de l'objet p :" + p.getClass().getName());
		// la MV sait toujours d'où l'objet a été instancié

		//transtypage descendant//down-casting
		Utilisateur u2 = (Utilisateur)p;
		System.out.print("MARIE JOSEPH2 " + u2.getNom()+ "  "+ u2.getIdUtilisateur() + " dit :");u2.parle();

	}

}
