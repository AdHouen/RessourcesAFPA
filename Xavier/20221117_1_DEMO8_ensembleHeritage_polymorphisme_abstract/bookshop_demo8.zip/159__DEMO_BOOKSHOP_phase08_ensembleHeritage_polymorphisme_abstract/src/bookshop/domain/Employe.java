package bookshop.domain;

public class Employe extends Personne {

	public Employe(String nom, String prenom) {
		super(nom, prenom);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Employe [" + super.toString() + "]";
	}

	public static void main(String[] args) {
		Employe e = new Employe("Remi","Ergé" );
		System.out.println("un employe :" + e);

		System.out.println();
		System.out.print("Ergé " + e.getNom() + " dit :");e.parle();

	}

	@Override
	public void parle() {
		System.out.println("j'attends mon CDI depuis trop longtemps");
	}

}
