package biblio.metier_EcritureClasseMetierEntite;

public class BookshopException3 extends Exception {
	
	

	public BookshopException3() {
		super("Pb généric sur l'application Chat");
	}

	public BookshopException3(String message) {
		super(message);
	}



	public static void main(String[] args) throws BookshopException3 {
		System.out.println(new BookshopException3("Nombre maximum d'emprunts atteint"));
		System.out.println(new BookshopException3());
		System.out.println();
		throw new BookshopException3("une exception pour tester");
		
	}
	

}
