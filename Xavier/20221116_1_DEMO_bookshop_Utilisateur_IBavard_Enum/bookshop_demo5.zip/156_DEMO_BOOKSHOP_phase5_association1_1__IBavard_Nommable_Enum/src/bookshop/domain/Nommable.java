package bookshop.domain;

public interface Nommable {

	String getNom();

	void setNom(String nom);

}