package fr.afpa.util;

import javax.swing.JOptionPane;

public class CalculFactor {

	public static void main(String[] args) {
	    String input = null;//chaine saisie, et sert de flag pour la boucle
	    do
	    {
	      // Saisie d'un texte avec une boite de dialogue Ok / Annuler
	    	
	      input = JOptionPane.showInputDialog ("Entrez un nombre :");
	      
	      if (input != null) // input est égal à null si l'utilisateur a choisi <Annuler> pour sortir
	      {
	        long n = 0;
			long factN = 0;
			try {
				n = Long.parseLong (input);

				factN = fr.afpa.math.Math.factorielle (n);
				
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, e);
				continue;
			} catch (IllegalArgumentException e) {
				JOptionPane.showMessageDialog(null, e);
				continue;
			}
			
			JOptionPane.showMessageDialog (null, "Le résultat de "+ n + "!  vaut  " + factN);
	      }
	      else {}//plus bas, on sort de la boucle

	    } while (input != null);
	    
		System.exit(0);
	  }
	}
