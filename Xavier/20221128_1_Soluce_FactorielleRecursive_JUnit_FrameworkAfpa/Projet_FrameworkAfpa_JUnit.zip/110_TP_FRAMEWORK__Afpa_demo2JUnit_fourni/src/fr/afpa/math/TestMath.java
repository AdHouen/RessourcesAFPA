package fr.afpa.math;
import java.math.BigDecimal;
//import fr.afpa.math.Math;
//import static fr.afpa.math.Math.factorielle_recursif;

public class TestMath {//le cas de test //Test Case //@TestCase
	
public static void main(String[] args) {
	//factorielleTest_old();
	factorielleTest20();
	factorielleTestMoinsSept();
	factorielleTestZero();

	euroToDollarTest10();
	euroToDollarTest0();
}

//premier test unitaire //@Test
public static void factorielleTestZero() {
	//assertion : La factorielle de zero vaut 1
	if( Math.factorielle(0) == 1 )
		System.out.println(" :Test OK: La factorielle de zero vaut 1");
	else
		System.err.println(" :Test NOK : La factorielle de zero vaut 1");
}


public static void factorielleTest20() {
	if( Math.factorielle(20) == 2432902008176640000L)
		System.out.println(" :Test OK : La factorielle de 20 retourne 243290200....");
	else
		System.err.println(" :Test NOK : La factorielle de 20 retourne 243290200....");

System.out.println();
//un test unitaire
System.out.println("Assertion: La factorielle de -1 ne se calcule pas");
try {
	Math.factorielle(-1);
	
	System.err.println(" Test NOK  : La factorielle de -1 ne se calcule pas");//Le Test à échoué!

} catch (IllegalArgumentException e) {
	System.out.println(" Test OK : La factorielle de -1 ne se calcule pas" + e);
} catch (Exception e) {
	System.err.println(" Test NOK : La factorielle de -1 ne se calcule pas" + e);
}

System.out.println();

//un test unitaire
System.out.println("Assertion: La factorielle de 21 est hors limite");
try {
	Math.factorielle(21);
	
	System.err.println(" Test NOK :La factorielle de 21 est hors limite");

} catch (IllegalArgumentException e) {
	System.out.println(" Test OK : La factorielle de 21 est hors limite  \n" + e);
}

System.out.println();

//un test unitaire
System.out.println("Assertion: La factorielle de 45 est hors limite");
try {
	Math.factorielle(45);
	System.err.println(" Test NOK :La factorielle de 45 est hors limite");
} catch (IllegalArgumentException e) {
	System.out.println(" :Test OK : La factorielle de 45 est hors limite  \n" + e);
}
}
//test unitaire
public static void euroToDollarTest10() {
	if( Math.euroToDollar(new BigDecimal("10")).equals(new BigDecimal("11.88")) )
	{
		System.out.println("test réussi : 10 euros valent 11.88 dollars");
	}
	else
	{
		System.err.println("test en échec: 10 euros valent 11.88 dollars");
	}
}
//test unitaire
public static void euroToDollarTest0() {
	if( Math.euroToDollar(new BigDecimal("0")).equals(new BigDecimal("0")) )
	{
		System.out.println("test réussi: 0 euros valent 0 dollars");
	}
	else
	{
		System.err.println("test en échec: 0 euros valent 0 dollars");
	}
}

//!!A NE PAS FAIRE !!! plrs assertions dans un test unitaire
//public static void factorielleTest2() {
//	if( factorielle_recursif(0)==1 && factorielle_recursif(1)==1 && factorielle__old(3)==6)
//		System.out.println(" :Test OK:Le test factorielleTest2");
//	else {
//		//System.out.println ("Pas très précis, on ne sait pas quel test échoué");
//		System.err.println(" :Test NOK:Le test factorielleTest2 a échoué!");
//	}
//}
public static void factorielleTestMoinsSept() {
	if( Math.factorielle_recursif(-7) == -1 )
		System.out.println(" :Test OK : La factorielle de -7 retourne -1");
	else
		System.err.println(" :Test NOK : La factorielle de -7 retourne -1");
}
}

