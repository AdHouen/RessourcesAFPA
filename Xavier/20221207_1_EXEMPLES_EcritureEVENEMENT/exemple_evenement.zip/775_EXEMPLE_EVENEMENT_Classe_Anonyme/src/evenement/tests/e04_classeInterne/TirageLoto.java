package evenement.tests.e04_classeInterne;
import javax.swing.*;import java.awt.*;import java.awt.event.*;
//
//  CHOIX DES EXEMPLES AFPA
//pour les listener: une classe interne (inner class) � la frame 
/////////////////////////////////////////////////////////////////
@SuppressWarnings("serial")
public class TirageLoto extends JFrame
{
//	visibilit� private
private JLabel lblResultatLoto;
private JButton cmdNouveauTirage;

private JButton cmdBouton2;
private JButton cmdBouton3;
private JButton cmdBouton4;

public TirageLoto(){
	super("Resultats de Loto");
	//this.setSize(420, 320);
	//this.setResizable(false);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	this.getContentPane().setLayout(new GridLayout (2, 1));
	
	initControles();
	this.pack();
	this.setVisible(true);
}
//Pour les objets �couteurs
//Classe interne nomm�e en Java  (inner class)
///////////////////////////////////
class EcouteurNouveauTirage implements ActionListener
{
	public void actionPerformed(ActionEvent ev) {
		// Mise a jour du label auquel on a acc�s sans passer de param�tre !!
		lblResultatLoto.setText( evenement.outils.TirageLotoFactory.newInstance().toString() );
		//pensez � intancier puis abonner aupr�s du contr�le
	}
}
class EcouteurBouton2 implements ActionListener
{
	public void actionPerformed(ActionEvent ev) {
		System.out.println("traitement bouton 2");
		//pensez � intancier puis abonner aupr�s du contr�le
	}
}
//Ecouteur commun � plusieurs composants (sur le m�me �v�nement)
class EcouteurTousLesBoutons implements ActionListener
{
	public void actionPerformed(ActionEvent ev) {
		//Si plrs boutons, on doit rep�rer lequel a �t� cliqu�
		//ev.getSource() comparaison aux ...  r�f�rences des composants
		if( ev.getSource() == cmdBouton3 )//comparaison de r�f�rences
			System.out.println("traitement bouton 3");
		else if( ev.getSource() == cmdBouton4 )//comparaison de r�f�rences
			System.out.println("traitement bouton 4");
		else
			throw new RuntimeException("Pb : cas non pr�vue");
	}
}
public void initControles(){
	lblResultatLoto = new JLabel ("                        ");
	
	cmdNouveauTirage = new JButton ("Nouveau tirage");
	// Abonnement de l'objet-Listener (EcouteurNouveauTirage) aupr�s du bouton
	cmdNouveauTirage.addActionListener( new EcouteurNouveauTirage () );
	
	cmdBouton2 = new JButton("2222");
	//intancier l'objet Listener   puis l'abonner aupr�s du contr�le
	cmdBouton2.addActionListener( new EcouteurBouton2 () );
	
	cmdBouton3 = new JButton("3333");
	cmdBouton4 = new JButton("4444");
	
	//intancier l'objet Listener   puis l'abonner aupr�s du contr�le
	EcouteurTousLesBoutons ecouteurTousLesBoutons = new EcouteurTousLesBoutons ();
	
	//cmdBouton3.addActionListener( new EcouteurTousLesBoutons () );
	//cmdBouton4.addActionListener( new EcouteurTousLesBoutons () );
	cmdBouton3.addActionListener( ecouteurTousLesBoutons );
	cmdBouton4.addActionListener( ecouteurTousLesBoutons );

	this.getContentPane().add(cmdNouveauTirage);
	this.getContentPane().add(lblResultatLoto);
	this.getContentPane().add(cmdBouton2);
	this.getContentPane().add(cmdBouton3);
	this.getContentPane().add(cmdBouton4);
}
public static void main(String[] args) {
	new TirageLoto();
}}
