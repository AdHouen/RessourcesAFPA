package fr.afpa.util;

import javax.swing.JOptionPane;
//import static fr.afpa.math.Math.factorielle;
import fr.afpa.math.Math;

public class CalculFactor__old {

public static void main(String[] args) {
    String saisie = null;
    do
    {
      // Entrée d'un texte avec une fenêtre modale
      saisie = JOptionPane.showInputDialog ("Entrez un nombre :");

      //saisie vaut null si l'utilisateur a choisi Annuler ou le widget croix
      if (saisie != null) 
      {
    	
        long n = Long.parseLong (saisie);
    	
        long factN = Math.factorielle_recursif (n);

		if( factN < 0 )
			JOptionPane.showMessageDialog (null, "Résultat impossible pour ce nombre :"
						+ n + "    code erreur :" + factN );
		else
			JOptionPane.showMessageDialog (null, n + "!  vaut " + factN);
      }
    } while (saisie != null);

	System.exit(0);
}}
