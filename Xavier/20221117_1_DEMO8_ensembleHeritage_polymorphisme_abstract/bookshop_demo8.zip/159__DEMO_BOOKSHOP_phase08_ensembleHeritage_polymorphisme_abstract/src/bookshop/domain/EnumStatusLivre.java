package bookshop.domain;

public enum EnumStatusLivre {
PRETE, DISPONIBLE, SUPPRIME


}
