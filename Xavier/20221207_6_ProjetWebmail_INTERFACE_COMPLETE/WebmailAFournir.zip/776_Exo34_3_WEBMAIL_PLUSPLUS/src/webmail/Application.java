/*
 * Cr�� le 17 oct. 2003
 */
package webmail;

import javax.swing.*;

/**
 *
 *
 *@author afpa
 *@version 1.0
 */
public class Application {

	
	public Application ()
	{
		FenetrePrincipale frm = new FenetrePrincipale();
		frm.setVisible(true);

	}

	public static void main(String[] args) 
	{
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); 
//        	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); 
//			UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
			JFrame.setDefaultLookAndFeelDecorated(true);
			JDialog.setDefaultLookAndFeelDecorated(true);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		new Application();
	}
}
