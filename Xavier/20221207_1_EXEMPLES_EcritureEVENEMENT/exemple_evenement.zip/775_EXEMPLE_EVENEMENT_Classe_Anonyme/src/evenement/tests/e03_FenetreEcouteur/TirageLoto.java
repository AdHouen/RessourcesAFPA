package evenement.tests.e03_FenetreEcouteur;
import javax.swing.*;import java.awt.*;
import java.awt.event.*;

//La fen�tre joue aussi le r�le d'�couteur
//Les r�f�rences des composants ne sont plus pass�es en param�tre
/////////////////////////////////////////////////////////////////
@SuppressWarnings("serial")
public class TirageLoto extends JFrame implements ActionListener{
	//visibilit� private
	private JLabel lblResultatLoto; //affichage du tirage loto
	private JButton cmdNouveauTirage;//Le bouton
	
	public TirageLoto(){
		super("Resultats de Loto");
		//this.setSize(420, 320);//this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new GridLayout (2, 1));
		initControles();
		
		this.pack();
		this.setVisible(true);	
	}
	public void initControles(){
		cmdNouveauTirage = new JButton ("Nouveau tirage");
		lblResultatLoto = new JLabel ();
		this.getContentPane().add(cmdNouveauTirage);
		this.getContentPane().add(lblResultatLoto);
		
		// Abonnement de l'objet Listener aupr�s du bouton
		cmdNouveauTirage.addActionListener( this );
	}
	public void actionPerformed(ActionEvent ev) {
		// Mise a jour du label avec les num�ros d'un nouveau tirage
		lblResultatLoto.setText( evenement.outils.TirageLotoFactory.newInstance().toString() );
	}
	public static void main(String[] args) {
		new TirageLoto();
	}
}
