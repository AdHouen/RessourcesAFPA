package fr.afpa.math;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Math {
	public static  BigDecimal VAL_1EURO = new BigDecimal("1.1882");

	public static BigDecimal euroToDollar(BigDecimal euros)
	{
		BigDecimal resultat = euros.multiply(VAL_1EURO);
		resultat = resultat.setScale(2, RoundingMode.HALF_UP);
		return resultat;
	}
	public static BigDecimal dollarToEuro(BigDecimal dollars)
	{
		return dollars.divide( VAL_1EURO, 2, RoundingMode.HALF_UP );
	}
	
  public static long factorielle (long n)
  {
    // Tester les cas limites n < 0  , n=22 , et n très grand
	if( n < 0 ||  20 < n){
		throw new IllegalArgumentException("Argument hors limite");
	}
	else if (n <= 1) 
      return 1; // --> on retourne 1 (et arrêt de la récursivité)
    else
      return n * factorielle(n - 1);// Appel récursif à factorielle
  }


/**
 * Rappels Mathématiques:
 *   fact(x)= x! = x * (x - 1) * (x - 2) * ... * 2 * 1
 *   x! = x * (x-1)!
 *   
 *   0! = 1
 *   1! = 1
 *   2! = 2
 *   3! = 6
 * 
 *   fact(x) = x * (x - (1)) * (x - (2)) * ... * (x - (x -2)) * (x - (x -1))
 */
  /**cette méthode calcule la factorielle
   * @param x nombre dont on veut la factorielle
   * @return  la factorielle de x
   * @return  -1 paramètre négatif
   * @return  -2 paramètre trop grand */
  public static long factorielleFor (long x)
  {
	// Test du paramètre : les valeur interdites n < 0  , n=21 et plus 
    long result;
	if( x < 0 ){
		
		System.out.println("Pb méthode factorielle, paramètre négatif :" + x );
		return -1;	// --> on sort car erreur
	}
	else if( x >= 21){
		System.out.println("Pb méthode factorielle, paramètre trop grand :" + x );
		return -2;	// --> on sort car erreur
	}
	else if (x == 0)
		return 1;	// --> pour 0, on sort le résultat 1
	else if (x == 1)
		return 1;	// --> pour 1, on renvoie le résultat 1
    else
    {
		result = x;
		for( long i = (x-1); i >=1; i--){
			result = result * i;
	    }
        return result;
    }
  }//factorielleFor
  /**
  * cette méthode calcule la factorielle
  * elle utilise la récursivité
  * @param x nombre dont on veut la factorielle
  * @return  le résultat factorielle de x
  * @return  -1 paramètre négatif
  * @return  -2 paramètre trop grand
  */
  public static long factorielle_recursif (long x)
  {
  // Tester les cas limites n < 0  , n=21 , et n très grand
  if( x < 0 ) {
	System.out.println("Pb paramètre négatif pour la méthode factorielle, :" + x );
  	return -1;					// --> on sort car erreur
  }
  else if( x >= 21){
	System.out.println("Pb paramètre trop grand pour la méthode factorielle,  :" + x );
  	return -2;					// --> on sort car erreur
  }
  else if (x == 0)
	return 1;		// --> pour 0 ,on renvoie 1
  else if (x == 1)
    return 1;		// --> pour 1,on renvoie 1 ( + arrêt de la récursivité)
  else
    return x * factorielle_recursif (x - 1);// Appel récursif à factorielle
  }		  

  
  
  
  
public static void main(String[] args) {
	long result = fr.afpa.math.Math.factorielleFor(4L);
	System.out.println("La factorielle de 4 vaut :" + result);
	
	result = fr.afpa.math.Math.factorielle_recursif(1L);
	System.out.println("La factorielle de 1 vaut :" + result);
	
	System.out.println("10 euros valent 11.88 dollars :"
			+  euroToDollar(new BigDecimal("10")));
	
	System.out.println("10 dollars valent 8,42 euros :"
			+  dollarToEuro(new BigDecimal("10")));

}
}
