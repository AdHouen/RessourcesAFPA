package evenement.tests.e05_classeImpliciteAnonyme_Lambda;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class TirageLotoOld
{
	public static void main(String[] args)
	{
		// Attention !!!!labelLoto doit etre declare "final" pour
		//pouvoir etre utilise dans la classe anonyme
		final JLabel lblResultatLoto = new JLabel ();

		JButton cmdNouveauTirage = new JButton ("Nouveau tirage");

		// Abonnement de l'objet Listener (anonyme) aupr�s du 
		//bouton et pour les clics
		cmdNouveauTirage.addActionListener( new ActionListener ()
			{
				public void actionPerformed( ActionEvent ev )
				{
					// Mise a jour du label avec les numeros d'un nouveau tirage
					
					// Attention !!!!labelLoto doit etre declare final pour pouvoir etre
					// utilise dans la classe anonyme
					lblResultatLoto.setText( evenement.outils.TirageLotoFactory.newInstance().toString() );
				}
			}
		);
		JFrame fenetre = new JFrame ("Resultat du Loto");

		// Affichage du bouton et du label l'un sous l'autre
		fenetre.getContentPane().setLayout(new GridLayout (2, 1));

		fenetre.getContentPane().add(cmdNouveauTirage);
		fenetre.getContentPane().add(lblResultatLoto);
		fenetre.pack();
		fenetre.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		fenetre.setVisible(true);
	}
}
