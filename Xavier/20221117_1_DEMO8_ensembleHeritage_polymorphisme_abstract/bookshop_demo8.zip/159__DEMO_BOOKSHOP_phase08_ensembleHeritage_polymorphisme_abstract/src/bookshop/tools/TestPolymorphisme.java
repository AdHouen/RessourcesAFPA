package bookshop.tools;

import java.util.Arrays;

import bookshop.domain.*;

public class TestPolymorphisme {

	public static void main(String[] args) {
		/////////////////////
		//Polymorphisme
		/////////////////////

		Personne[] personnes = {
				new Utilisateur("MARIE JOSEPH", "Carthy", "34890",null)
				, new Auteur("Remi","Ergé" )};
		for(Personne var : personnes) {
			System.out.print("La personne " + var.getNom()+ "  dit :"); var.parle();
		}
		System.out.println();
		Arrays.asList(personnes).forEach(x->x.parle());

		System.out.println();
		IBavard [] bavards= {
				new Utilisateur("MARIE JOSEPH", "Carthy", "34890",null)
				, new Auteur("Remi","Ergé" )};
		for(IBavard var : bavards) {
			//System.out.print("La personne " + var.getNom()+ "  dit :"); var.parle();
			System.out.print("La personne   dit :"); var.parle();
		}
		System.out.println();
		Arrays.asList(bavards).forEach(x->x.parle());

	}

}
