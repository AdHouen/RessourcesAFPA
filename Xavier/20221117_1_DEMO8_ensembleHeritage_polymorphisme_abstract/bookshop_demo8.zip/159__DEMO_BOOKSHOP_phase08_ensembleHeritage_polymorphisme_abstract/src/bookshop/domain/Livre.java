package bookshop.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Abstraction du livre de la librairie (bookshop)
 * @author xav
 */
public class Livre {

	/** le titre du livre*/
	private String titre = "titre_inconnu";
	
	private String auteur;
	
	private String editeur;
	
	private int nbPages;
	
	private LocalDate dateEmprunt;
	
	private boolean disponible;
	//EnumStatusLivre status = EnumStatusLivre.DISPONIBLE;
	
	private int countNew;
	static DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("dd/MM/yy");



	//titre auteur editeur nbPages dateEmprunt disponible countNew

	public Livre(String leTitre,String auteur, String editeur, int nbPages, LocalDate dateEmprunt, boolean disponible){
		//règle métier//règle de gestion//business rule
//		if(leTitre == null)
//			this.titre = "titre_inconnu";
//		else
//			titre = leTitre;
		setTitre(leTitre);
		
		this.auteur = auteur;
		this.editeur = editeur;
		
//		if( nbPages <0)
//			throw new IllegalArgumentException("Le nb de pages doit être positif");
//		else
//			this.nbPages = nbPages;
		setNbPages(nbPages);
		
		this.nbPages = nbPages;
		this.dateEmprunt = dateEmprunt;
		this.disponible = disponible;
		countNew++;
	}
	public Livre(String leTitre,String auteur, String editeur, int nbPages, LocalDate dateEmprunt){
		this(leTitre, auteur,  editeur,  nbPages,  dateEmprunt, true);
//		//règle métier//règle de gestion//business rule
//		if(leTitre == null)
//			this.titre = "titre_inconnu";
//		else
//			titre = leTitre;
//		
//		this.auteur = auteur;
//		this.editeur = editeur;
//		
//		if( nbPages <0)
//			throw new IllegalArgumentException("Le nb de pages doit être positif");
//		else
//			this.nbPages = nbPages;
//		
//		this.nbPages = nbPages;
//		this.dateEmprunt = dateEmprunt;
//		this.disponible = true;//règle métier
//		countNew++;

	}
	public Livre(){
		//super();
		this(null, "auteur_inconnu",  "editeur_inconnu",  0,  LocalDate.now());
	}
	//////////////////////////////////////////
	//ACCESSEURS  //getters
	public String getTitre() {
		return titre;
	}
	public String getAuteur() {
		return auteur;
	}
	public String getEditeur() {
		return editeur;
	}
	public int getNbPages() {
		return nbPages;
	}
	public LocalDate getDateEmprunt() {
		return dateEmprunt;
	}
	public boolean isDisponible() {
		return disponible;
	}
	public int getCountNew() {
		return countNew;
	}
	//////////////////////////////////////////
	//MUTATEURS  //setters
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
	public void setEditeur(String editeur) {
		this.editeur = editeur;
	}
	public void setDateEmprunt(LocalDate dateEmprunt) {
		this.dateEmprunt = dateEmprunt;
	}
	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}
	public void setCountNew(int countNew) {
		this.countNew = countNew;
	}
	
	//setters//modificateurs avec des règles métier
	public void setTitre(String leTitre) {
		if(leTitre == null)
			this.titre = "titre_inconnu";
		else
			titre = leTitre;
	}
	
	public void setNbPages(int nbPages) {
		if( nbPages <0)
			throw new IllegalArgumentException("Le nb de pages doit être positif");
		else
			this.nbPages = nbPages;
	}
	public void afficheToi() {
		System.out.println("titre :" + this.titre +" auteur :" + auteur + " editeur :" + editeur
				+ " nbPages :" + nbPages  + " dateEmprunt :" + dateEmprunt
				+ " disponible :" + disponible + " countNew :" + countNew);
	}
	//public void afficheToi() { System.out.println(this);}

	//Méthodes polymorphes
	@Override public String toString() {
		return "titre :" + this.titre +" auteur :" + auteur + " editeur :" + editeur
				+ " nbPages :" + nbPages  + " dateEmprunt :" + (dateEmprunt!=null? dateEmprunt.format(dtf):"pas de date")
				+ " disponible :" + disponible  + " countNew :" + countNew;//+ "  status :" + status
	}
	
	/* j'essaie de coder equals()*/
//	@Override public boolean equals( Livre autre)//  ==> ERREUR  ERREUR  ERREUR
//	{   return true; }
	
	@Override
	public boolean equals(Object autre) {
		if (this == autre)
			return true;
		if (autre == null)
			return false;
		if (getClass() != autre.getClass())
			return false;
		Livre other = (Livre) autre;
		if (nbPages != other.nbPages)
			return false;
		
		return true;
	}
	@Override public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + nbPages;
		return result;
	}

//	public EnumStatusLivre getStatus() {
//		return status;
//	}
//	public void setStatus(EnumStatusLivre status) {
//		this.status = status;
//	}
	@Override
	protected void finalize() throws Throwable {
		//super.finalize();//deprecated
		System.out.println("Arrrrrrrrrrrrrrrrrh je meurs .....");
	}

	


	public static void main(String[] args) throws Throwable {
			Livre L1 = new Livre();
			System.out.println("Mon premier livre (toString):" + L1);
			System.out.println();
			L1.afficheToi();
			System.out.println();

			///////////////////////
			//Pour le scenario d'emprunt
			// VOIR LA CLASSE ScenarioEmprunt
			///////////////////////
			
			///////////////////////////////
			//test des constructeurs
			///////////////////////////////
			//surcharge des constructeurs ,  this()
			//ils s'appuient sur les setters
			
			Livre L2 = new Livre("Astérix","Uderzo", "Dargo", 64, null, true);

			System.out.println("Mon deuxième livre (toString):" + L2);
			System.out.println();
			
			Livre L3 = new Livre("Tintin", "Ergé", "Dargo", 67, LocalDate.now(), true);
			
			/*test titre du livre à null*/
			//Livre L3 = new Livre(null,"Ergé", "Dargo", 67, LocalDate.now(), true);

			System.out.println("Mon trois livre (toString):" + L3);
			System.out.println();

			/*nombre de page du livre à -1*/
			//Livre L4 = new Livre("Quatre","Uderzaa", "Dargaa", -1, LocalDate.now());
			Livre L4 = new Livre("Quatre","Uderzaa", "Dargaa", 24, LocalDate.now());

			System.out.println("Mon quatre livre (toString):" + L4);
			System.out.println();
			
			//L4 = null;
			//L4.finalize();
			
			//L2.afficheToi();
			
	}
}
